/* ═══════════════════════════════════════════════════════════════
   IBRA Soft Workshop ERP — السندات والدفعات (v5 - نهائي)
   ═══════════════════════════════════════════════════════════════ */

const Vouchers = {
  currentView: 'list',
  filter: 'all',

  render() {
    const content = document.getElementById('content');
    if (this.currentView === 'list') {
      this.renderList(content);
    } else {
      this.renderForm(content);
    }
  },

  renderList(content) {
    const vouchers = DB.get('vouchers') || [];
    const cashboxes = DB.get('cashboxes') || [];
    
    let filtered = vouchers;
    if (this.filter === 'receipt') filtered = vouchers.filter(v => v.type === 'receipt');
    if (this.filter === 'payment') filtered = vouchers.filter(v => v.type === 'payment');
    filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const totalReceipts = vouchers.filter(v => v.type === 'receipt').length;
    const totalPayments = vouchers.filter(v => v.type === 'payment').length;

    let html = `
      <div class="page-header">
        <h1 class="page-title">السندات والدفعات</h1>
      </div>

      <!-- البطاقة الرئيسية -->
      <div class="voucher-hero-v4">
        <div class="vhv4-header">
          <div class="vhv4-icon">🧾</div>
          <div>
            <h2>السندات والدفعات</h2>
            <p>إدارة كاملة لجميع السندات</p>
          </div>
        </div>
        <div class="vhv4-stats">
          <div class="vhv4-stat ${this.filter === 'all' ? 'active' : ''}" onclick="Vouchers.setFilter('all')">
            <div class="vhv4-stat-value">${vouchers.length}</div>
            <div class="vhv4-stat-label">الكل</div>
          </div>
          <div class="vhv4-stat ${this.filter === 'receipt' ? 'active' : ''}" onclick="Vouchers.setFilter('receipt')">
            <div class="vhv4-stat-value" style="color:#4ade80;">${totalReceipts}</div>
            <div class="vhv4-stat-label">📥 قبض</div>
          </div>
          <div class="vhv4-stat ${this.filter === 'payment' ? 'active' : ''}" onclick="Vouchers.setFilter('payment')">
            <div class="vhv4-stat-value" style="color:#f87171;">${totalPayments}</div>
            <div class="vhv4-stat-label">📤 صرف</div>
          </div>
        </div>
      </div>

      <!-- أزرار الإنشاء -->
      <div class="voucher-actions-v4">
        <button class="vav4-btn vav4-receipt" onclick="Vouchers.openNew('receipt')">
          <div class="vav4-icon">📥</div>
          <div>
            <b>سند قبض</b>
            <span>استلام مبلغ من عميل / مورد</span>
          </div>
        </button>
        <button class="vav4-btn vav4-payment" onclick="Vouchers.openNew('payment')">
          <div class="vav4-icon">📤</div>
          <div>
            <b>سند صرف</b>
            <span>دفع مبلغ لمورد / موظف</span>
          </div>
        </button>
      </div>

      <!-- قائمة السندات -->
      <div class="voucher-list-header">
        <h3>${this.filter === 'all' ? 'جميع السندات' : (this.filter === 'receipt' ? 'سندات القبض' : 'سندات الصرف')}</h3>
        <span class="voucher-count">${filtered.length} سند</span>
      </div>

      <div class="voucher-list-v4">
        ${filtered.length ? filtered.map(v => this.renderVoucherCard(v, cashboxes)).join('') : `
          <div class="empty-state">
            <div class="icon">🧾</div>
            <p>لا توجد سندات في هذه الفئة.</p>
          </div>
        `}
      </div>
    `;
    content.innerHTML = html;
    this.injectStyles();
  },

  renderVoucherCard(v, cashboxes) {
    const isReceipt = v.type === 'receipt';
    const cur = v.currency || 'YER';
    const curIcon = cur === 'SAR' ? '🇸🇦' : '🇾🇪';
    const box = cashboxes.find(b => b.id === v.cashboxId);
    const color = isReceipt ? 'receipt' : 'payment';
    const realPartyName = this.getRealPartyName(v);

    return `
      <div class="voucher-card-v4 vcv4-${color}">
        <div class="vcv4-header">
          <div class="vcv4-type">
            ${isReceipt ? '📥 سند قبض' : '📤 سند صرف'}
          </div>
          <div class="vcv4-number">${v.number}</div>
        </div>
        <div class="vcv4-body">
          <div class="vcv4-row">
            <div class="vcv4-label">الجهة</div>
            <div class="vcv4-value">${Utils.esc(realPartyName)}</div>
          </div>
          ${box ? `
            <div class="vcv4-row">
              <div class="vcv4-label">الصندوق</div>
              <div class="vcv4-value">💼 ${Utils.esc(box.name)}</div>
            </div>
          ` : ''}
          <div class="vcv4-amount-box">
            <div class="vcv4-amount-label">المبلغ</div>
            <div class="vcv4-amount-value">${Utils.money(v.amount, cur)}</div>
            <div class="vcv4-currency">${curIcon} ${cur === 'SAR' ? 'ريال سعودي' : 'ريال يمني'}</div>
          </div>
          <div class="vcv4-date">📅 ${Utils.date(v.createdAt, true)}</div>
        </div>
        <div class="vcv4-actions">
          <button class="vcv4-action-btn vcv4-print" onclick="Vouchers.print('${v.id}')">
            🖨️ طباعة
          </button>
          <button class="vcv4-action-btn vcv4-delete" onclick="Vouchers.remove('${v.id}')">
            🗑️
          </button>
        </div>
      </div>
    `;
  },

  // ✅ دالة لجلب الاسم الحقيقي للجهة (بدلاً من الـ ID)
  getRealPartyName(v) {
    let name = v.partyName;
    if (v.party && !['custom', 'expenses', 'rent', 'other'].includes(v.party)) {
      const emp = DB.find('employees', v.party);
      const cust = DB.find('customers', v.party);
      const supp = DB.find('suppliers', v.party);
      
      if (emp) name = emp.name;
      else if (cust) name = cust.name;
      else if (supp) name = supp.name;
    }
    return name || 'غير محدد';
  },

  setFilter(filter) { this.filter = filter; this.render(); },
  openNew(type) { this.currentView = type; this.render(); },
  backToList() { this.currentView = 'list'; this.render(); },

  renderForm(content) {
    const isReceipt = this.currentView === 'receipt';
    const title = isReceipt ? 'سند قبض' : 'سند صرف';
    const color = isReceipt ? '#ea580c' : '#dc2626';
    const gradient = isReceipt ? 'linear-gradient(135deg, #ea580c, #f59e0b)' : 'linear-gradient(135deg, #dc2626, #b91c1c)';

    const customers = DB.get('customers') || [];
    const suppliers = DB.get('suppliers') || [];
    const employees = DB.get('employees') || [];
    const cashboxes = DB.get('cashboxes') || [];

    const partyOptions = [
      { group: 'عام', items: [
        { value: 'custom', label: '✏️ إدخال اسم مخصص' },
        { value: 'expenses', label: '💸 المصروفات (أكل وشرب)' },
        { value: 'rent', label: '🏢 إيجارات' }
      ]},
      { group: 'الموظفون', items: employees.filter(e => e.status === 'active').map(e => ({ value: e.id, label: `👤 ${e.name}` })) },
      { group: 'العملاء', items: customers.map(c => ({ value: c.id, label: `👥 ${c.name}` })) },
      { group: 'الموردون', items: suppliers.map(s => ({ value: s.id, label: `🚚 ${s.name}` })) }
    ];

    let optionsHtml = '';
    partyOptions.forEach(group => {
      if (group.items.length === 0) return;
      optionsHtml += `<optgroup label="${group.group}">`;
      group.items.forEach(item => {
        optionsHtml += `<option value="${item.value}">${item.label}</option>`;
      });
      optionsHtml += `</optgroup>`;
    });

    let html = `
      <div class="voucher-form-header" style="background: ${gradient};">
        <button class="vfh-back" onclick="Vouchers.backToList()">←</button>
        <div class="vfh-title">
          <h2>${title}</h2>
          <p>${isReceipt ? 'استلام مبلغ من جهة' : 'دفع مبلغ إلى جهة'}</p>
        </div>
      </div>

      <div class="voucher-form-v4">
        <!-- البيانات -->
        <div class="vff-section">
          <div class="vff-section-title">📋 بيانات السند</div>
          
          <div class="vff-field">
            <label>التاريخ</label>
            <input type="text" value="${Utils.date(new Date())}" readonly style="background:#f8fafc;">
          </div>

          <div class="vff-field">
            <label>${isReceipt ? 'استلمنا من' : 'دفعنا إلى'} <span style="color:var(--danger);">*</span></label>
            <select id="vParty" onchange="Vouchers.onPartyChange(this)">
              <option value="">— اختر الجهة —</option>
              ${optionsHtml}
            </select>
          </div>

          <div class="vff-field" id="customPartyField" style="display:none;">
            <label>اسم الجهة المخصص</label>
            <input type="text" id="vCustomParty" placeholder="أدخل اسم الجهة">
          </div>

          <div class="vff-field">
            <label>البيان / ملاحظات</label>
            <textarea id="vNotes" rows="2" placeholder="${isReceipt ? 'سبب الاستلام...' : 'سبب الدفع...'}"></textarea>
          </div>
        </div>

        <!-- المبلغ -->
        <div class="vff-section vff-amount-section-${isReceipt ? 'receipt' : 'payment'}">
          <div class="vff-section-title">💰 المبلغ</div>

          <div class="vff-field">
            <label>الصندوق</label>
            <select id="vCashbox">
              ${cashboxes.map(b => `<option value="${b.id}">💼 ${b.name}</option>`).join('')}
            </select>
          </div>

          <div class="vff-field">
            <label>العملة</label>
            <select id="vCurrency">
              <option value="YER">🇾🇪 ريال يمني (YER)</option>
              <option value="SAR">🇸🇦 ريال سعودي (SAR)</option>
            </select>
          </div>

          <div class="vff-field">
            <label>المبلغ <span style="color:var(--danger);">*</span></label>
            <input type="number" id="vAmount" value="0" step="1" min="1"
              style="font-size:24px; font-weight:900; text-align:center; color:${color};">
          </div>
        </div>

        <!-- الأزرار -->
        <div class="vff-actions">
          <button class="vff-btn vff-cancel" onclick="Vouchers.backToList()">✖ إلغاء</button>
          <button class="vff-btn vff-save" style="background:${gradient};" onclick="Vouchers.save('${this.currentView}')">
            💾 حفظ السند
          </button>
        </div>
      </div>
    `;
    content.innerHTML = html;
  },

  onPartyChange(select) {
    document.getElementById('customPartyField').style.display = select.value === 'custom' ? 'block' : 'none';
  },

  save(type) {
    const partySelect = document.getElementById('vParty').value;
    const customParty = document.getElementById('vCustomParty') ? document.getElementById('vCustomParty').value.trim() : '';
    const notes = document.getElementById('vNotes').value.trim();
    const cashboxId = document.getElementById('vCashbox').value;
    const currency = document.getElementById('vCurrency').value;
    const amount = Number(document.getElementById('vAmount').value) || 0;

    if (amount <= 0) { UI.toast('⚠️ أدخل مبلغاً صحيحاً', 'error'); return; }

    let partyName = partySelect;
    if (partySelect === 'custom') partyName = customParty;
    if (!partyName) { UI.toast('⚠️ اختر الجهة', 'error'); return; }

    const isReceipt = type === 'receipt';
    const number = Utils.docNumber(isReceipt ? 'RC' : 'PV');

    const voucher = DB.insert('vouchers', {
      number, type, party: partySelect, partyName, notes,
      amount, currency, cashboxId,
      createdAt: new Date().toISOString(),
      createdBy: Auth.current().userId
    });

    DB.insert('payments', {
      type: isReceipt ? 'in' : 'out',
      amount, currency, cashboxId,
      refId: voucher.id,
      refType: 'voucher',
      note: `${isReceipt ? 'سند قبض' : 'سند صرف'} ${number} - ${partyName}`,
      date: new Date().toISOString()
    });

    UI.toast(`✅ تم حفظ ${isReceipt ? 'سند القبض' : 'سند الصرف'}`, 'success');
    setTimeout(() => this.showSuccess(voucher), 300);
    this.backToList();
  },

  showSuccess(voucher) {
    const isReceipt = voucher.type === 'receipt';
    const realName = this.getRealPartyName(voucher);
    const bodyHtml = `
      <div style="text-align:center; padding:20px 0;">
        <div style="font-size:60px; margin-bottom:12px;">${isReceipt ? '📥' : '📤'}</div>
        <h3 style="color:var(--success); margin-bottom:8px;">تم الحفظ بنجاح!</h3>
        <p style="font-size:18px; font-weight:800; color:var(--primary); margin-bottom:16px;">${voucher.number}</p>
        <div style="background:var(--bg); padding:12px; border-radius:8px;">
          <div style="font-size:13px; margin-bottom:4px;">الجهة: <b>${realName}</b></div>
          <div style="font-size:18px; font-weight:800;">${Utils.money(voucher.amount, voucher.currency)}</div>
        </div>
      </div>
    `;
    UI.openModal('عملية ناجحة', bodyHtml, `
      <button class="btn btn-ghost" onclick="UI.closeModal()">إغلاق</button>
      <button class="btn btn-primary" onclick="Vouchers.print('${voucher.id}')">🖨️ طباعة</button>
    `);
  },

  remove(id) {
    if (!confirm('حذف السند؟')) return;
    DB.remove('vouchers', id);
    this.render();
    UI.toast('✅ تم الحذف', 'success');
  },

  print(id) {
    const v = DB.find('vouchers', id);
    if (!v) return;
    const settings = DB.getSettings();
    const isReceipt = v.type === 'receipt';
    const color = isReceipt ? '#ea580c' : '#dc2626';
    const gradient = isReceipt ? 'linear-gradient(135deg, #ea580c, #f59e0b)' : 'linear-gradient(135deg, #dc2626, #b91c1c)';
    const cur = v.currency || 'YER';
    const cashbox = DB.find('cashboxes', v.cashboxId);
    
    // ✅ جلب الاسم الحقيقي للجهة
    const realName = this.getRealPartyName(v);

    const win = window.open('', '_blank');
    const html = `
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>${isReceipt ? 'سند قبض' : 'سند صرف'} ${v.number}</title>
        <style>
          * { margin:0; padding:0; box-sizing:border-box; }
          body { font-family:'Segoe UI',Tahoma,Arial,sans-serif; background:#f5f5f5; padding:20px; direction:rtl; }
          .voucher { background:#fff; max-width:420px; margin:0 auto; border-radius:14px; overflow:hidden; box-shadow:0 4px 20px rgba(0,0,0,0.15); }
          .v-header { background:${gradient}; color:#fff; padding:28px 24px; text-align:center; }
          .v-type { font-size:24px; font-weight:900; margin-bottom:6px; }
          .v-number { font-size:13px; font-weight:700; background:rgba(255,255,255,0.25); padding:5px 16px; border-radius:20px; display:inline-block; margin-top:10px; }
          .v-body { padding:24px; }
          .v-section { background:#f8fafc; padding:14px; border-radius:10px; margin-bottom:14px; border-right:3px solid ${color}; }
          .v-row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px dashed #e2e8f0; font-size:13px; }
          .v-row:last-child { border-bottom:none; }
          .v-label { color:#64748b; }
          .v-value { font-weight:700; color:#1e293b; }
          .v-amount-box { background:${isReceipt ? '#fef3c7' : '#fee2e2'}; border:2px dashed ${color}; border-radius:12px; padding:20px; text-align:center; margin:16px 0; }
          .v-amount-label { font-size:11px; color:${color}; font-weight:700; margin-bottom:6px; }
          .v-amount-value { font-size:32px; font-weight:900; color:${color}; }
          .v-currency { font-size:12px; color:#64748b; margin-top:4px; }
          .v-signatures { display:flex; justify-content:space-between; margin-top:24px; padding-top:16px; border-top:1px dashed #e2e8f0; }
          .sig-box { text-align:center; flex:1; }
          .sig-line { height:40px; border-bottom:1px solid #cbd5e1; margin:0 15px; }
          .sig-label { font-size:11px; color:#64748b; margin-top:6px; }
          .v-footer { background:#f8fafc; padding:14px; text-align:center; font-size:10px; color:#94a3b8; }
          .print-actions { position:fixed; top:15px; left:15px; display:flex; gap:8px; z-index:999; }
          .btn { padding:10px 20px; border:none; border-radius:10px; font-family:inherit; font-weight:700; cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,0.15); }
          .btn-p { background:${color}; color:#fff; }
          .btn-c { background:#fff; color:#333; border:1px solid #ddd; }
          @media print { body { background:#fff; padding:0; } .voucher { box-shadow:none; border-radius:0; max-width:100%; } .print-actions { display:none; } }
        </style>
      </head>
      <body>
        <div class="print-actions">
          <button class="btn btn-p" onclick="window.print()">🖨️ طباعة</button>
          <button class="btn btn-c" onclick="window.close()">✖ إغلاق</button>
        </div>
        <div class="voucher">
          <div class="v-header">
            ${settings.companyLogo ? `<img src="${settings.companyLogo}" style="width:50px; height:50px; object-fit:contain; margin-bottom:10px;">` : ''}
            <div class="v-type">${isReceipt ? '📥 سند قبض' : '📤 سند صرف'}</div>
            <div class="v-number">${v.number}</div>
          </div>
          <div class="v-body">
            <div class="v-section">
              <div class="v-row"><span class="v-label">التاريخ:</span><span class="v-value">${Utils.date(v.createdAt, true)}</span></div>
              <!-- ✅ هنا تم استخدام الاسم الحقيقي -->
              <div class="v-row"><span class="v-label">${isReceipt ? 'استلمنا من:' : 'دفعنا إلى:'}</span><span class="v-value">${Utils.esc(realName)}</span></div>
              ${cashbox ? `<div class="v-row"><span class="v-label">الصندوق:</span><span class="v-value">${Utils.esc(cashbox.name)}</span></div>` : ''}
              ${v.notes ? `<div class="v-row"><span class="v-label">البيان:</span><span class="v-value">${Utils.esc(v.notes)}</span></div>` : ''}
            </div>
            <div class="v-amount-box">
              <div class="v-amount-label">المبلغ</div>
              <div class="v-amount-value">${Utils.money(v.amount, cur)}</div>
              <div class="v-currency">${cur === 'SAR' ? '🇸🇦 ريال سعودي' : '🇾🇪 ريال يمني'}</div>
            </div>
            <div class="v-signatures">
              <div class="sig-box"><div class="sig-line"></div><div class="sig-label">توقيع المستلم</div></div>
              <div class="sig-box"><div class="sig-line"></div><div class="sig-label">توقيع الإدارة</div></div>
            </div>
          </div>
          <div class="v-footer">
            ${settings.companyName || 'ورشة التصنيع'} — ${settings.companyPhone || ''}<br>
            صادر بواسطة IBRA Soft ERP
          </div>
        </div>
      </body>
      </html>
    `;
    win.document.write(html);
    win.document.close();
  },

  injectStyles() {
    if (document.getElementById('vouchers-styles-v4')) return;
    const style = document.createElement('style');
    style.id = 'vouchers-styles-v4';
    style.innerHTML = `
      .voucher-hero-v4 {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border-radius: 20px; padding: 20px; color: #fff;
        margin-bottom: 16px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        position: relative; overflow: hidden;
      }
      .voucher-hero-v4::before {
        content: ''; position: absolute;
        top: -50px; right: -50px; width: 250px; height: 250px;
        background: radial-gradient(circle, rgba(255,255,255,0.1), transparent 70%);
        border-radius: 50%;
      }
      .vhv4-header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; position: relative; z-index: 1; }
      .vhv4-icon { font-size: 42px; }
      .vhv4-header h2 { font-size: 20px; font-weight: 800; margin: 0; }
      .vhv4-header p { font-size: 12px; opacity: 0.8; margin-top: 2px; }
      .vhv4-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; position: relative; z-index: 1; }
      .vhv4-stat { background: rgba(255,255,255,0.1); border-radius: 12px; padding: 12px 8px; text-align: center; cursor: pointer; border: 2px solid transparent; transition: all 0.2s; }
      .vhv4-stat.active { background: #fff; color: #1e293b; border-color: #f59e0b; }
      .vhv4-stat-value { font-size: 22px; font-weight: 800; }
      .vhv4-stat-label { font-size: 11px; opacity: 0.9; margin-top: 2px; }

      .voucher-actions-v4 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
      .vav4-btn { background: #fff; border: 2px solid var(--border); border-radius: 14px; padding: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer; font-family: inherit; transition: all 0.2s; text-align: right; }
      .vav4-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(0,0,0,0.1); }
      .vav4-receipt { border-color: #f59e0b; }
      .vav4-payment { border-color: #dc2626; }
      .vav4-icon { font-size: 28px; }
      .vav4-btn b { display: block; font-size: 14px; color: var(--text); }
      .vav4-btn span { font-size: 11px; color: var(--text-muted); }

      .voucher-list-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; padding: 0 4px; }
      .voucher-list-header h3 { font-size: 15px; font-weight: 800; margin: 0; }
      .voucher-count { font-size: 12px; color: var(--text-muted); }
      .voucher-list-v4 { display: grid; gap: 12px; }

      .voucher-card-v4 { background: #fff; border-radius: 16px; overflow: hidden; border: 1px solid var(--border); box-shadow: 0 2px 8px rgba(0,0,0,0.05); transition: all 0.2s; }
      .voucher-card-v4:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }
      .vcv4-receipt { border-right: 4px solid #ea580c; }
      .vcv4-payment { border-right: 4px solid #dc2626; }
      .vcv4-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #f8fafc; border-bottom: 1px solid var(--border); }
      .vcv4-type { font-size: 13px; font-weight: 800; }
      .vcv4-receipt .vcv4-type { color: #ea580c; }
      .vcv4-payment .vcv4-type { color: #dc2626; }
      .vcv4-number { font-size: 11px; color: var(--text-muted); font-family: monospace; }
      .vcv4-body { padding: 14px 16px; }
      .vcv4-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; }
      .vcv4-label { color: var(--text-muted); }
      .vcv4-value { font-weight: 700; color: var(--text); }
      .vcv4-amount-box { background: #f8fafc; padding: 14px; border-radius: 10px; text-align: center; margin: 12px 0; }
      .vcv4-amount-label { font-size: 11px; color: var(--text-muted); margin-bottom: 4px; }
      .vcv4-amount-value { font-size: 22px; font-weight: 900; }
      .vcv4-receipt .vcv4-amount-value { color: #ea580c; }
      .vcv4-payment .vcv4-amount-value { color: #dc2626; }
      .vcv4-currency { font-size: 11px; color: var(--text-muted); margin-top: 4px; }
      .vcv4-date { font-size: 11px; color: var(--text-muted); text-align: center; }
      .vcv4-actions { padding: 10px 16px; background: #f8fafc; border-top: 1px solid var(--border); display: flex; gap: 6px; }
      .vcv4-action-btn { flex: 1; padding: 8px; border: none; border-radius: 8px; font-size: 11px; font-weight: 700; cursor: pointer; font-family: inherit; }
      .vcv4-print { background: #dbeafe; color: #1e40af; }
      .vcv4-delete { background: #fee2e2; color: #991b1b; flex: 0.4; }

      .voucher-form-header { border-radius: 16px; padding: 20px; color: #fff; display: flex; align-items: center; gap: 14px; margin-bottom: 16px; }
      .vfh-back { background: rgba(255,255,255,0.25); color: #fff; border: none; width: 40px; height: 40px; border-radius: 50%; font-size: 18px; cursor: pointer; font-weight: 700; }
      .vfh-title h2 { font-size: 20px; font-weight: 800; margin: 0; }
      .vfh-title p { font-size: 12px; opacity: 0.9; margin-top: 2px; }
      .voucher-form-v4 { display: grid; gap: 14px; }
      .vff-section { background: #fff; border-radius: 14px; padding: 16px; border: 1px solid var(--border); }
      .vff-amount-section-receipt { background: #fef3c7; border: 2px solid #f59e0b; }
      .vff-amount-section-payment { background: #fee2e2; border: 2px solid #dc2626; }
      .vff-section-title { font-size: 14px; font-weight: 800; margin-bottom: 12px; color: var(--text); }
      .vff-field { margin-bottom: 12px; }
      .vff-field:last-child { margin-bottom: 0; }
      .vff-field label { display: block; font-size: 12px; font-weight: 600; color: var(--text-muted); margin-bottom: 6px; }
      .vff-field input, .vff-field select, .vff-field textarea { width: 100%; padding: 11px 14px; border: 1px solid var(--border); border-radius: 10px; font-family: inherit; font-size: 14px; background: #fff; outline: none; box-sizing: border-box; }
      .vff-field input:focus, .vff-field select:focus, .vff-field textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37,99,235,0.1); }
      .vff-actions { display: flex; gap: 10px; padding: 14px; background: #fff; border-radius: 14px; border: 1px solid var(--border); }
      .vff-btn { padding: 12px; border: none; border-radius: 12px; font-size: 14px; font-weight: 700; cursor: pointer; font-family: inherit; }
      .vff-cancel { flex: 1; background: #fff; color: var(--text); border: 1px solid var(--border); }
      .vff-save { flex: 2; color: #fff; }
    `;
    document.head.appendChild(style);
  }
};

console.log('✅ Vouchers v5 loaded');