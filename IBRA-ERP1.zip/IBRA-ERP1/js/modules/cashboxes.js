/* ═══════════════════════════════════════════════════════════════
   IBRA Soft Workshop ERP — الصناديق والخزائن (v3 - متعدد العملات)
   ═══════════════════════════════════════════════════════════════ */

const Cashboxes = {
  render() {
    const content = document.getElementById('content');
    
    let cashboxes = DB.get('cashboxes') || [];
    if (cashboxes.length === 0) {
      DB.insert('cashboxes', {
        name: 'الصندوق الرئيسي',
        openingBalanceYER: 0,
        openingBalanceSAR: 0,
        isMain: true,
        createdAt: new Date().toISOString()
      });
      cashboxes = DB.get('cashboxes');
    }

    const payments = DB.get('payments') || [];
    const expenses = DB.get('expenses') || [];
    const vouchers = DB.get('vouchers') || [];

    // حساب الأرصدة لكل صندوق (يمني وسعودي)
    const boxesData = cashboxes.map(box => {
      const boxPayments = payments.filter(p => p.cashboxId === box.id || (!p.cashboxId && box.isMain));
      const boxExpenses = expenses.filter(e => e.cashboxId === box.id || (!e.cashboxId && box.isMain));
      const boxVouchers = vouchers.filter(v => v.cashboxId === box.id || (!v.cashboxId && box.isMain));

      const openingYER = Number(box.openingBalanceYER) || 0;
      const openingSAR = Number(box.openingBalanceSAR) || 0;

      let inYER = 0, outYER = 0, inSAR = 0, outSAR = 0;
      
      const getCurrency = (item) => item.currency || 'YER';

      boxPayments.forEach(p => {
        if (p.type === 'in') {
          if (getCurrency(p) === 'SAR') inSAR += Number(p.amount) || 0; else inYER += Number(p.amount) || 0;
        } else {
          if (getCurrency(p) === 'SAR') outSAR += Number(p.amount) || 0; else outYER += Number(p.amount) || 0;
        }
      });
      
      boxExpenses.forEach(e => {
        if (getCurrency(e) === 'SAR') outSAR += Number(e.amount) || 0; else outYER += Number(e.amount) || 0;
      });
      
      boxVouchers.forEach(v => {
        if (v.type === 'receipt') {
          if (getCurrency(v) === 'SAR') inSAR += Number(v.amount) || 0; else inYER += Number(v.amount) || 0;
        } else {
          if (getCurrency(v) === 'SAR') outSAR += Number(v.amount) || 0; else outYER += Number(v.amount) || 0;
        }
      });

      return {
        ...box,
        balanceYER: openingYER + inYER - outYER,
        balanceSAR: openingSAR + inSAR - outSAR,
        totalInYER: inYER,
        totalOutYER: outYER,
        totalInSAR: inSAR,
        totalOutSAR: outSAR
      };
    });

    const totalCashYER = boxesData.reduce((sum, b) => sum + b.balanceYER, 0);
    const totalCashSAR = boxesData.reduce((sum, b) => sum + b.balanceSAR, 0);

    // حركات اليوم
    const today = Utils.today();
    const todayInYER = payments.filter(p => p.type === 'in' && p.date && p.date.startsWith(today) && (p.currency || 'YER') === 'YER')
      .reduce((s, p) => s + (Number(p.amount) || 0), 0);
    const todayOutYER = payments.filter(p => p.type === 'out' && p.date && p.date.startsWith(today) && (p.currency || 'YER') === 'YER')
      .reduce((s, p) => s + (Number(p.amount) || 0), 0)
      + expenses.filter(e => e.date && e.date.startsWith(today) && (e.currency || 'YER') === 'YER')
      .reduce((s, e) => s + (Number(e.amount) || 0), 0);

    let html = `
      <div class="page-header">
        <h1 class="page-title">الصناديق والخزائن</h1>
      </div>

      <!-- البطاقة الرئيسية -->
      <div class="cashbox-hero">
        <div class="ch-title">إجمالي النقدية في جميع الصناديق</div>
        
        <div style="display:flex; justify-content:center; gap:20px; margin: 16px 0; position:relative; z-index:1;">
           <div style="text-align:center;">
             <div style="font-size:11px; opacity:0.85; margin-bottom:4px;">🇾🇪 ريال يمني</div>
             <div style="font-size:24px; font-weight:900;">${Utils.money(totalCashYER, 'YER')}</div>
           </div>
           <div style="width:1px; background:rgba(255,255,255,0.3);"></div>
           <div style="text-align:center;">
             <div style="font-size:11px; opacity:0.85; margin-bottom:4px;">🇸🇦 ريال سعودي</div>
             <div style="font-size:24px; font-weight:900;">${Utils.money(totalCashSAR, 'SAR')}</div>
           </div>
        </div>

        <div class="ch-today-row">
          <div class="ch-today-item">
            <div class="ch-today-label">مقبوضات اليوم (يمني)</div>
            <div class="ch-today-value in">+${Utils.money(todayInYER, 'YER')}</div>
          </div>
          <div class="ch-today-divider"></div>
          <div class="ch-today-item">
            <div class="ch-today-label">مدفوعات اليوم (يمني)</div>
            <div class="ch-today-value out">-${Utils.money(todayOutYER, 'YER')}</div>
          </div>
        </div>
      </div>

      <!-- أزرار سريعة -->
      <div class="cashbox-actions">
        <button class="ca-btn" onclick="Cashboxes.openTransfer()">🔄 <span>تحويل</span></button>
        <button class="ca-btn" onclick="Cashboxes.openDeposit()">➕ <span>إيداع</span></button>
        <button class="ca-btn" onclick="Cashboxes.openWithdraw()">➖ <span>سحب</span></button>
        <button class="ca-btn ca-primary" onclick="Cashboxes.openAddBox()">➕ <span>صندوق جديد</span></button>
        <button class="ca-btn ca-secondary" onclick="Cashboxes.printAllReport()">🖨️ <span>طباعة</span></button>
      </div>

      <!-- بطاقات الصناديق -->
      <div class="cashboxes-grid">
        ${boxesData.map(box => this.renderBoxCard(box)).join('')}
      </div>

      <!-- آخر الحركات -->
      <div class="card" style="padding:0;">
        <div class="trans-header">
          <h3>🕐 آخر الحركات</h3>
        </div>
        <div class="trans-list">
          ${this.renderRecentTransactions(payments, expenses, vouchers)}
        </div>
      </div>
    `;

    content.innerHTML = html;
    this.injectStyles();
  },

  renderBoxCard(box) {
    return `
      <div class="cashbox-card">
        <div class="cc-header">
          <div class="cc-icon">💼</div>
          <div class="cc-info">
            <div class="cc-name">${Utils.esc(box.name)}</div>
            <div class="cc-currency">متعدد العملات</div>
          </div>
          <div class="cc-actions">
            <button class="cc-action-btn cc-print" onclick="Cashboxes.printBoxReport('${box.id}')" title="طباعة">🖨️</button>
            <button class="cc-action-btn cc-edit" onclick="Cashboxes.editBox('${box.id}')" title="تعديل">✏️</button>
            ${!box.isMain ? `<button class="cc-action-btn cc-delete" onclick="Cashboxes.removeBox('${box.id}')" title="حذف">🗑️</button>` : ''}
          </div>
        </div>
        
        <div class="cc-balance-box" style="display:flex; justify-content:space-between; text-align:center; padding:14px;">
          <div style="flex:1;">
            <div class="cc-balance-label">🇾🇪 الرصيد (يمني)</div>
            <div class="cc-balance-value" style="font-size:16px; color:#d97706;">${Utils.money(box.balanceYER, 'YER')}</div>
          </div>
          <div style="width:1px; background:var(--border);"></div>
          <div style="flex:1;">
            <div class="cc-balance-label">🇸🇦 الرصيد (سعودي)</div>
            <div class="cc-balance-value" style="font-size:16px; color:#0891b2;">${Utils.money(box.balanceSAR, 'SAR')}</div>
          </div>
        </div>
        
        <div class="cc-stats">
          <div class="cc-stat cc-stat-in">
            <div class="ccs-label">إجمالي القبض (يمني)</div>
            <div class="ccs-value">${Utils.money(box.totalInYER, 'YER')}</div>
          </div>
          <div class="cc-stat cc-stat-out">
            <div class="ccs-label">إجمالي الصرف (يمني)</div>
            <div class="ccs-value">${Utils.money(box.totalOutYER, 'YER')}</div>
          </div>
        </div>
      </div>
    `;
  },

  renderRecentTransactions(payments, expenses, vouchers) {
    const all = [
      ...payments.map(p => ({ ...p, _source: 'payment' })),
      ...expenses.map(e => ({ ...e, _source: 'expense', type: 'out' })),
      ...vouchers.map(v => ({
        id: v.id,
        type: v.type === 'receipt' ? 'in' : 'out',
        amount: v.amount,
        note: `${v.type === 'receipt' ? 'سند قبض' : 'سند صرف'} - ${v.partyName}`,
        date: v.createdAt,
        currency: v.currency,
        _source: 'voucher'
      }))
    ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 20);

    if (!all.length) return '<div class="empty-state" style="padding:30px;"><p>لا توجد حركات بعد.</p></div>';

    return all.map(t => {
      const isIn = t.type === 'in';
      const cur = t.currency || 'YER';
      return `
        <div class="trans-item">
          <div class="trans-icon trans-icon-${isIn ? 'in' : 'out'}">${isIn ? '⬇️' : '⬆️'}</div>
          <div class="trans-info">
            <div class="trans-title">${Utils.esc(t.note || (isIn ? 'إيراد' : 'مصروف'))}</div>
            <div class="trans-date">${Utils.date(t.date, true)}</div>
          </div>
          <div class="trans-amount trans-amount-${isIn ? 'in' : 'out'}">${isIn ? '+' : '-'}${Utils.money(t.amount, cur)}</div>
        </div>
      `;
    }).join('');
  },

  // ─── إضافة صندوق ───
  openAddBox() {
    if (!Auth.require('accounting.manage', 'إدارة المحاسبة')) return;

    const body = `
      <div style="display:grid; gap:14px;">
        <div>
          <label style="font-size:12px; font-weight:600; color:var(--text-muted);">اسم الصندوق</label>
          <input type="text" id="newBoxName" placeholder="مثال: صندوق الكاشير" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">رصيد افتتاحي 🇾🇪 (يمني)</label>
            <input type="number" id="newBoxOpeningYER" value="0" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
          </div>
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">رصيد افتتاحي 🇸🇦 (سعودي)</label>
            <input type="number" id="newBoxOpeningSAR" value="0" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
          </div>
        </div>
      </div>
    `;

    UI.openModal('➕ إضافة صندوق جديد', body, `
      <button class="btn btn-ghost" onclick="UI.closeModal()">إلغاء</button>
      <button class="btn btn-primary" onclick="Cashboxes.saveNewBox()">💾 حفظ</button>
    `);
  },

  saveNewBox() {
    const name = document.getElementById('newBoxName').value.trim();
    const openingYER = Number(document.getElementById('newBoxOpeningYER').value) || 0;
    const openingSAR = Number(document.getElementById('newBoxOpeningSAR').value) || 0;
    
    if (!name) { UI.toast('⚠️ أدخل اسم الصندوق', 'error'); return; }
    
    DB.insert('cashboxes', { 
      name, 
      openingBalanceYER: openingYER, 
      openingBalanceSAR: openingSAR, 
      isMain: false, 
      createdAt: new Date().toISOString() 
    });
    
    UI.closeModal();
    this.render();
    UI.toast('✅ تم إضافة الصندوق', 'success');
  },

  removeBox(id) {
    if (!confirm('حذف الصندوق؟')) return;
    DB.remove('cashboxes', id);
    this.render();
    UI.toast('✅ تم الحذف', 'success');
  },

  editBox(id) {
    const box = DB.find('cashboxes', id);
    if (!box) return;

    const body = `
      <div style="display:grid; gap:14px;">
        <div>
          <label style="font-size:12px; font-weight:600; color:var(--text-muted);">اسم الصندوق</label>
          <input type="text" id="editBoxName" value="${Utils.esc(box.name)}" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">الرصيد الافتتاحي 🇾🇪</label>
            <input type="number" id="editBoxOpeningYER" value="${box.openingBalanceYER || 0}" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
          </div>
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">الرصيد الافتتاحي 🇸🇦</label>
            <input type="number" id="editBoxOpeningSAR" value="${box.openingBalanceSAR || 0}" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
          </div>
        </div>
      </div>
    `;
    UI.openModal('✏️ تعديل الصندوق', body, `
      <button class="btn btn-ghost" onclick="UI.closeModal()">إلغاء</button>
      <button class="btn btn-primary" onclick="Cashboxes.saveEditBox('${id}')">💾 حفظ</button>
    `);
  },

  saveEditBox(id) {
    const name = document.getElementById('editBoxName').value.trim();
    const openingYER = Number(document.getElementById('editBoxOpeningYER').value) || 0;
    const openingSAR = Number(document.getElementById('editBoxOpeningSAR').value) || 0;
    
    if (!name) { UI.toast('⚠️ أدخل اسم الصندوق', 'error'); return; }
    DB.update('cashboxes', id, { name, openingBalanceYER: openingYER, openingBalanceSAR: openingSAR });
    UI.closeModal();
    this.render();
    UI.toast('✅ تم التعديل', 'success');
  },

  // ─── عمليات مالية ───
  openDeposit() {
    const boxes = DB.get('cashboxes') || [];
    const body = `
      <div style="display:grid; gap:14px;">
        <div>
          <label style="font-size:12px; font-weight:600; color:var(--text-muted);">الصندوق</label>
          <select id="depBox" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
            ${boxes.map(b => `<option value="${b.id}">${b.name}</option>`).join('')}
          </select>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">العملة</label>
            <select id="depCurrency" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
              <option value="YER">🇾🇪 يمني</option>
              <option value="SAR">🇸🇦 سعودي</option>
            </select>
          </div>
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">المبلغ</label>
            <input type="number" id="depAmount" value="0" min="1" style="width:100%; padding:12px; border:1px solid var(--border); border-radius:8px; margin-top:4px; font-size:16px; font-weight:800; text-align:center; color:#10b981;">
          </div>
        </div>
        <div>
          <label style="font-size:12px; font-weight:600; color:var(--text-muted);">ملاحظات</label>
          <input type="text" id="depNote" placeholder="سبب الإيداع..." style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
        </div>
      </div>
    `;
    UI.openModal('➕ إيداع في الصندوق', body, `
      <button class="btn btn-ghost" onclick="UI.closeModal()">إلغاء</button>
      <button class="btn btn-success" onclick="Cashboxes.saveDeposit()">✅ إيداع</button>
    `);
  },

  saveDeposit() {
    const boxId = document.getElementById('depBox').value;
    const currency = document.getElementById('depCurrency').value;
    const amount = Number(document.getElementById('depAmount').value) || 0;
    const note = document.getElementById('depNote').value.trim();
    if (amount <= 0) return;

    DB.insert('payments', {
      type: 'in', amount, currency, cashboxId: boxId,
      note: note || 'إيداع',
      date: new Date().toISOString()
    });

    UI.closeModal();
    this.render();
    UI.toast('✅ تم الإيداع', 'success');
  },

  openWithdraw() {
    const boxes = DB.get('cashboxes') || [];
    const body = `
      <div style="display:grid; gap:14px;">
        <div>
          <label style="font-size:12px; font-weight:600; color:var(--text-muted);">الصندوق</label>
          <select id="wdBox" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
            ${boxes.map(b => `<option value="${b.id}">${b.name}</option>`).join('')}
          </select>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">العملة</label>
            <select id="wdCurrency" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
              <option value="YER">🇾🇪 يمني</option>
              <option value="SAR">🇸🇦 سعودي</option>
            </select>
          </div>
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">المبلغ</label>
            <input type="number" id="wdAmount" value="0" min="1" style="width:100%; padding:12px; border:1px solid var(--border); border-radius:8px; margin-top:4px; font-size:16px; font-weight:800; text-align:center; color:#dc2626;">
          </div>
        </div>
        <div>
          <label style="font-size:12px; font-weight:600; color:var(--text-muted);">ملاحظات</label>
          <input type="text" id="wdNote" placeholder="سبب السحب..." style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
        </div>
      </div>
    `;
    UI.openModal('➖ سحب من الصندوق', body, `
      <button class="btn btn-ghost" onclick="UI.closeModal()">إلغاء</button>
      <button class="btn btn-danger" onclick="Cashboxes.saveWithdraw()">💸 سحب</button>
    `);
  },

  saveWithdraw() {
    const boxId = document.getElementById('wdBox').value;
    const currency = document.getElementById('wdCurrency').value;
    const amount = Number(document.getElementById('wdAmount').value) || 0;
    const note = document.getElementById('wdNote').value.trim();
    if (amount <= 0) return;

    DB.insert('payments', {
      type: 'out', amount, currency, cashboxId: boxId,
      note: note || 'سحب',
      date: new Date().toISOString()
    });

    UI.closeModal();
    this.render();
    UI.toast('✅ تم السحب', 'success');
  },

  openTransfer() {
    const boxes = DB.get('cashboxes') || [];
    if (boxes.length < 2) { UI.toast('⚠️ تحتاج صندوقين على الأقل', 'warning'); return; }
    
    const body = `
      <div style="display:grid; gap:14px;">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">من صندوق</label>
            <select id="trFrom" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
              ${boxes.map(b => `<option value="${b.id}">${b.name}</option>`).join('')}
            </select>
          </div>
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">إلى صندوق</label>
            <select id="trTo" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
              ${boxes.map(b => `<option value="${b.id}">${b.name}</option>`).join('')}
            </select>
          </div>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">العملة</label>
            <select id="trCurrency" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px;">
              <option value="YER">🇾🇪 يمني</option>
              <option value="SAR">🇸🇦 سعودي</option>
            </select>
          </div>
          <div>
            <label style="font-size:12px; font-weight:600; color:var(--text-muted);">المبلغ</label>
            <input type="number" id="trAmount" value="0" min="1" style="width:100%; padding:10px; border:1px solid var(--border); border-radius:8px; margin-top:4px; font-weight:800; text-align:center;">
          </div>
        </div>
      </div>
    `;
    UI.openModal('🔄 تحويل بين الصناديق', body, `
      <button class="btn btn-ghost" onclick="UI.closeModal()">إلغاء</button>
      <button class="btn btn-primary" onclick="Cashboxes.saveTransfer()">🔄 تحويل</button>
    `);
  },

  saveTransfer() {
    const from = document.getElementById('trFrom').value;
    const to = document.getElementById('trTo').value;
    const currency = document.getElementById('trCurrency').value;
    const amount = Number(document.getElementById('trAmount').value) || 0;
    if (amount <= 0 || from === to) return;

    DB.insert('payments', { type: 'out', amount, currency, cashboxId: from, note: 'تحويل بين الصناديق', date: new Date().toISOString() });
    DB.insert('payments', { type: 'in', amount, currency, cashboxId: to, note: 'تحويل بين الصناديق', date: new Date().toISOString() });

    UI.closeModal();
    this.render();
    UI.toast('✅ تم التحويل', 'success');
  },

  // ─── طباعة ───
  printBoxReport(boxId) {
    const box = DB.find('cashboxes', boxId);
    if (!box) return;
    
    const payments = DB.get('payments') || [];
    const expenses = DB.get('expenses') || [];
    const vouchers = DB.get('vouchers') || [];
    const settings = DB.getSettings();
    const logo = settings.companyLogo || '';

    const boxPayments = payments.filter(p => p.cashboxId === boxId);
    const boxVouchers = vouchers.filter(v => v.cashboxId === boxId);
    const boxExpenses = expenses.filter(e => e.cashboxId === boxId);

    const win = window.open('', '_blank');
    const html = `
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>كشف حساب - ${box.name}</title>
        <style>
          * { margin:0; padding:0; box-sizing:border-box; }
          body { font-family:'Segoe UI',Tahoma,Arial,sans-serif; background:#f5f5f5; padding:20px; direction:rtl; }
          .page { background:#fff; max-width:800px; margin:0 auto; padding:30px; border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,0.1); }
          .header { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:3px solid #d97706; padding-bottom:16px; margin-bottom:20px; }
          .company-info h1 { font-size:20px; color:#d97706; margin-bottom:4px; font-weight:800; }
          .company-info p { font-size:11px; color:#64748b; }
          .company-logo { width:60px; height:60px; object-fit:contain; margin-bottom:8px; }
          .report-title { text-align:left; }
          .report-title h2 { font-size:22px; color:#1e293b; margin-bottom:4px; }
          .report-title p { font-size:12px; color:#64748b; }
          
          .box-info { background:#fef3c7; padding:16px; border-radius:10px; margin-bottom:20px; border-right:4px solid #d97706; }
          .box-info h3 { font-size:16px; color:#92400e; margin-bottom:8px; }
          
          .kpi-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:20px; }
          .kpi-box { padding:12px; border-radius:10px; text-align:center; }
          .kpi-yer { background:#fef3c7; }
          .kpi-sar { background:#cffafe; }
          .kpi-label { font-size:11px; font-weight:600; margin-bottom:4px; opacity:0.8; }
          .kpi-value { font-size:18px; font-weight:800; }
          .kpi-yer .kpi-value { color:#92400e; }
          .kpi-sar .kpi-value { color:#0c4a6e; }
          
          table { width:100%; border-collapse:collapse; font-size:12px; margin-bottom:20px; }
          thead { background:#1e293b; color:#fff; }
          th { padding:10px; text-align:right; font-weight:600; }
          td { padding:10px; border-bottom:1px solid #e2e8f0; }
          tbody tr:nth-child(even) { background:#f8fafc; }
          .in { color:#16a34a; font-weight:700; text-align:center; }
          .out { color:#dc2626; font-weight:700; text-align:center; }
          
          .footer { text-align:center; font-size:10px; color:#94a3b8; padding-top:20px; border-top:1px solid #e2e8f0; }
          .print-actions { position:fixed; top:15px; left:15px; display:flex; gap:8px; z-index:999; }
          .btn { padding:10px 20px; border:none; border-radius:8px; font-family:inherit; font-weight:700; cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,0.15); }
          .btn-p { background:#d97706; color:#fff; }
          .btn-c { background:#fff; color:#333; border:1px solid #ddd; }
          @media print { body { background:#fff; padding:0; } .page { box-shadow:none; } .print-actions { display:none; } }
        </style>
      </head>
      <body>
        <div class="print-actions">
          <button class="btn btn-p" onclick="window.print()">🖨️ طباعة</button>
          <button class="btn btn-c" onclick="window.close()">✖ إغلاق</button>
        </div>
        <div class="page">
          <div class="header">
            <div class="company-info">
              ${logo ? `<img src="${logo}" class="company-logo">` : ''}
              <h1>${settings.companyName || 'ورشة التصنيع'}</h1>
              <p>📞 ${settings.companyPhone || ''}</p>
            </div>
            <div class="report-title">
              <h2>كشف حساب صندوق</h2>
              <p>${Utils.date(new Date(), true)}</p>
            </div>
          </div>
          
          <div class="box-info">
            <h3>💼 ${Utils.esc(box.name)}</h3>
            <p style="font-size:11px;">الرصيد الافتتاحي: 🇾🇪 ${Utils.money(box.openingBalanceYER || 0, 'YER')} | 🇸🇦 ${Utils.money(box.openingBalanceSAR || 0, 'SAR')}</p>
          </div>

          <div class="kpi-grid">
            <div class="kpi-box kpi-yer">
              <div class="kpi-label">🇾🇪 الرصيد الحالي (يمني)</div>
              <div class="kpi-value">${Utils.money(box.balanceYER || 0, 'YER')}</div>
            </div>
            <div class="kpi-box kpi-sar">
              <div class="kpi-label">🇸🇦 الرصيد الحالي (سعودي)</div>
              <div class="kpi-value">${Utils.money(box.balanceSAR || 0, 'SAR')}</div>
            </div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>التاريخ</th>
                <th>البيان</th>
                <th>العملة</th>
                <th style="text-align:center;">داخل</th>
                <th style="text-align:center;">خارج</th>
              </tr>
            </thead>
            <tbody>
              ${[...boxPayments, ...boxVouchers].sort((a,b)=> new Date(b.date || b.createdAt) - new Date(a.date || a.createdAt)).map(t => {
                const isIn = t.type === 'in' || t.type === 'receipt';
                const cur = t.currency || 'YER';
                return `
                  <tr>
                    <td>${Utils.date(t.date || t.createdAt)}</td>
                    <td>${Utils.esc(t.note || t.partyName || '—')}</td>
                    <td>${cur === 'SAR' ? '🇸🇦' : '🇾🇪'}</td>
                    <td class="in">${isIn ? Utils.money(t.amount, cur) : '—'}</td>
                    <td class="out">${!isIn ? Utils.money(t.amount, cur) : '—'}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>

          <div class="footer">
            ${settings.companyName || 'ورشة التصنيع'} — تقرير صادر عن IBRA Soft ERP
          </div>
        </div>
      </body>
      </html>
    `;
    win.document.write(html);
    win.document.close();
  },

  printAllReport() {
    const boxes = DB.get('cashboxes') || [];
    const settings = DB.getSettings();
    const logo = settings.companyLogo || '';
    
    const boxesData = boxes.map(box => {
      const payments = DB.get('payments') || [];
      const expenses = DB.get('expenses') || [];
      const vouchers = DB.get('vouchers') || [];
      
      const boxPayments = payments.filter(p => p.cashboxId === box.id || (!p.cashboxId && box.isMain));
      const boxExpenses = expenses.filter(e => e.cashboxId === box.id || (!e.cashboxId && box.isMain));
      const boxVouchers = vouchers.filter(v => v.cashboxId === box.id || (!v.cashboxId && box.isMain));
      
      let inYER = 0, outYER = 0, inSAR = 0, outSAR = 0;
      boxPayments.forEach(p => {
        if (p.type === 'in') { if ((p.currency||'YER')==='SAR') inSAR += Number(p.amount)||0; else inYER += Number(p.amount)||0; }
        else { if ((p.currency||'YER')==='SAR') outSAR += Number(p.amount)||0; else outYER += Number(p.amount)||0; }
      });
      boxExpenses.forEach(e => { if ((e.currency||'YER')==='SAR') outSAR += Number(e.amount)||0; else outYER += Number(e.amount)||0; });
      boxVouchers.forEach(v => {
        if (v.type === 'receipt') { if ((v.currency||'YER')==='SAR') inSAR += Number(v.amount)||0; else inYER += Number(v.amount)||0; }
        else { if ((v.currency||'YER')==='SAR') outSAR += Number(v.amount)||0; else outYER += Number(v.amount)||0; }
      });
      
      return {
        ...box,
        balYER: (Number(box.openingBalanceYER)||0) + inYER - outYER,
        balSAR: (Number(box.openingBalanceSAR)||0) + inSAR - outSAR
      };
    });

    const totalYER = boxesData.reduce((s,b)=> s+b.balYER, 0);
    const totalSAR = boxesData.reduce((s,b)=> s+b.balSAR, 0);

    const win = window.open('', '_blank');
    const html = `
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>تقرير الصناديق</title>
        <style>
          * { margin:0; padding:0; box-sizing:border-box; }
          body { font-family:'Segoe UI',Tahoma,Arial,sans-serif; background:#f5f5f5; padding:20px; direction:rtl; }
          .page { background:#fff; max-width:800px; margin:0 auto; padding:30px; border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,0.1); }
          .header { text-align:center; border-bottom:3px solid #d97706; padding-bottom:16px; margin-bottom:20px; }
          .company-name { font-size:22px; font-weight:800; color:#d97706; }
          .report-title { font-size:16px; color:#1e293b; margin-top:4px; }
          .total-box { background:linear-gradient(135deg, #d97706, #92400e); color:#fff; padding:20px; border-radius:12px; text-align:center; margin-bottom:20px; display:flex; justify-content:space-around; }
          .total-label { font-size:11px; opacity:0.9; margin-bottom:4px; }
          .total-value { font-size:22px; font-weight:900; }
          table { width:100%; border-collapse:collapse; font-size:13px; }
          thead { background:#1e293b; color:#fff; }
          th { padding:10px; text-align:right; font-weight:600; }
          td { padding:10px; border-bottom:1px solid #e2e8f0; }
          tbody tr:nth-child(even) { background:#f8fafc; }
          .footer { text-align:center; font-size:10px; color:#94a3b8; padding-top:20px; border-top:1px solid #e2e8f0; margin-top:20px; }
          .print-actions { position:fixed; top:15px; left:15px; display:flex; gap:8px; z-index:999; }
          .btn { padding:10px 20px; border:none; border-radius:8px; font-family:inherit; font-weight:700; cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,0.15); }
          .btn-p { background:#d97706; color:#fff; }
          .btn-c { background:#fff; color:#333; border:1px solid #ddd; }
          @media print { body { background:#fff; padding:0; } .page { box-shadow:none; } .print-actions { display:none; } }
        </style>
      </head>
      <body>
        <div class="print-actions">
          <button class="btn btn-p" onclick="window.print()">🖨️ طباعة</button>
          <button class="btn btn-c" onclick="window.close()">✖ إغلاق</button>
        </div>
        <div class="page">
          <div class="header">
            ${logo ? `<img src="${logo}" style="width:50px; margin-bottom:8px;">` : ''}
            <div class="company-name">${settings.companyName || 'ورشة التصنيع'}</div>
            <div class="report-title">تقرير الصناديق</div>
            <div style="font-size:11px; color:#64748b; margin-top:4px;">${Utils.date(new Date(), true)}</div>
          </div>
          
          <div class="total-box">
            <div>
              <div class="total-label">🇾🇪 إجمالي اليمني</div>
              <div class="total-value">${Utils.money(totalYER, 'YER')}</div>
            </div>
            <div style="width:1px; background:rgba(255,255,255,0.3);"></div>
            <div>
              <div class="total-label">🇸🇦 إجمالي السعودي</div>
              <div class="total-value">${Utils.money(totalSAR, 'SAR')}</div>
            </div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>الصندوق</th>
                <th style="text-align:center;">🇾🇪 رصيد يمني</th>
                <th style="text-align:center;">🇸🇦 رصيد سعودي</th>
              </tr>
            </thead>
            <tbody>
              ${boxesData.map(b => `
                <tr>
                  <td style="font-weight:700;">${Utils.esc(b.name)}</td>
                  <td style="text-align:center; font-weight:700; color:#92400e;">${Utils.money(b.balYER, 'YER')}</td>
                  <td style="text-align:center; font-weight:700; color:#0c4a6e;">${Utils.money(b.balSAR, 'SAR')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <div class="footer">
            ${settings.companyName || 'ورشة التصنيع'} — تقرير صادر عن IBRA Soft ERP
          </div>
        </div>
      </body>
      </html>
    `;
    win.document.write(html);
    win.document.close();
  },

  injectStyles() {
    if (document.getElementById('cashbox-styles')) return;
    const style = document.createElement('style');
    style.id = 'cashbox-styles';
    style.innerHTML = `
      .cashbox-hero {
        background: linear-gradient(135deg, #d97706 0%, #92400e 100%);
        border-radius: 20px; padding: 24px; color: #fff;
        margin-bottom: 16px; box-shadow: 0 10px 30px rgba(217,119,6,0.3);
        position: relative; overflow: hidden;
      }
      .cashbox-hero::before {
        content: ''; position: absolute; top: -50px; right: -50px;
        width: 250px; height: 250px;
        background: radial-gradient(circle, rgba(255,255,255,0.2), transparent 70%);
        border-radius: 50%;
      }
      .ch-title { font-size: 14px; opacity: 0.95; font-weight: 600; text-align: center; position: relative; z-index: 1; }
      .ch-main-value { font-size: 38px; font-weight: 900; text-align: center; margin: 12px 0 20px; position: relative; z-index: 1; letter-spacing: -1px; }
      .ch-today-row { display: grid; grid-template-columns: 1fr auto 1fr; gap: 10px; align-items: center; background: rgba(255,255,255,0.15); border-radius: 12px; padding: 12px; position: relative; z-index: 1; }
      .ch-today-item { text-align: center; }
      .ch-today-label { font-size: 11px; opacity: 0.85; margin-bottom: 4px; }
      .ch-today-value { font-size: 14px; font-weight: 800; }
      .ch-today-value.in { color: #86efac; }
      .ch-today-value.out { color: #fca5a5; }
      .ch-today-divider { width: 1px; height: 30px; background: rgba(255,255,255,0.3); }
      
      .cashbox-actions {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(90px, 1fr));
        gap: 8px; margin-bottom: 16px;
      }
      .ca-btn {
        background: #fff; border: 1px solid var(--border);
        border-radius: 12px; padding: 12px 6px;
        display: flex; flex-direction: column;
        align-items: center; gap: 4px;
        font-family: inherit; font-size: 11px; font-weight: 700;
        color: var(--text); cursor: pointer;
        transition: all 0.2s;
      }
      .ca-btn:hover { border-color: #d97706; transform: translateY(-1px); }
      .ca-primary { background: linear-gradient(135deg, #d97706, #92400e); color: #fff; border-color: transparent; }
      .ca-secondary { background: #f8fafc; }
      
      .cashboxes-grid { display: grid; grid-template-columns: 1fr; gap: 12px; margin-bottom: 16px; }
      @media (min-width: 768px) { .cashboxes-grid { grid-template-columns: 1fr 1fr; } }
      
      .cashbox-card {
        background: #fff; border-radius: 16px;
        border: 1px solid var(--border); padding: 16px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
      }
      
      .cc-header { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
      .cc-icon {
        width: 44px; height: 44px;
        background: linear-gradient(135deg, #d97706, #92400e);
        color: #fff; border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 22px;
      }
      .cc-info { flex: 1; }
      .cc-name { font-size: 14px; font-weight: 800; color: var(--text); }
      .cc-currency { font-size: 10px; color: var(--text-muted); }
      .cc-actions { display: flex; gap: 4px; }
      .cc-action-btn {
        width: 30px; height: 30px; border: none; border-radius: 8px;
        font-size: 13px; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
      }
      .cc-print { background: #dbeafe; }
      .cc-edit { background: #f1f5f9; }
      .cc-delete { background: #fee2e2; }
      
      .cc-balance-box { background: #f8fafc; border: 1px solid var(--border); border-radius: 10px; padding: 14px; margin-bottom: 10px; }
      .cc-balance-label { font-size: 10px; color: var(--text-muted); margin-bottom: 4px; }
      .cc-balance-value { font-size: 18px; font-weight: 900; }
      
      .cc-stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 6px; }
      .cc-stat { padding: 8px; border-radius: 8px; text-align: center; }
      .cc-stat-in { background: #dcfce7; }
      .cc-stat-out { background: #fee2e2; }
      .ccs-label { font-size: 10px; font-weight: 600; opacity: 0.8; }
      .ccs-value { font-size: 12px; font-weight: 800; margin-top: 2px; }
      .cc-stat-in .ccs-value { color: #166534; }
      .cc-stat-out .ccs-value { color: #991b1b; }
      
      .trans-header { padding: 14px 18px; border-bottom: 1px solid var(--border); background: #f8fafc; }
      .trans-header h3 { font-size: 14px; margin: 0; }
      .trans-list { padding: 6px 0; }
      .trans-item { display: flex; align-items: center; gap: 12px; padding: 12px 18px; border-bottom: 1px solid var(--border); }
      .trans-item:last-child { border-bottom: none; }
      .trans-icon { width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; }
      .trans-icon-in { background: #dcfce7; color: #166534; }
      .trans-icon-out { background: #fee2e2; color: #991b1b; }
      .trans-info { flex: 1; min-width: 0; }
      .trans-title { font-size: 13px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .trans-date { font-size: 10px; color: var(--text-muted); margin-top: 2px; }
      .trans-amount { font-size: 14px; font-weight: 800; white-space: nowrap; }
      .trans-amount-in { color: #166534; }
      .trans-amount-out { color: #991b1b; }
    `;
    document.head.appendChild(style);
  }
};

console.log('✅ Cashboxes v3 loaded');